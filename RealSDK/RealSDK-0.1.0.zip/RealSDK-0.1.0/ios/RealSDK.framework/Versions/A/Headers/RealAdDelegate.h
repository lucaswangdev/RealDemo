//
//  RealAdDelegate.h
//  RealSDK
//
//  Created by lucaswang on 2024/1/8.
//

#import <Foundation/Foundation.h>

@protocol RealAdDelegate <NSObject>

- (void)adDidFinish;

@end
