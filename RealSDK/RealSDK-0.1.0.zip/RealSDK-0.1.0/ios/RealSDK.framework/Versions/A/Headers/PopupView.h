//
//  PopupView.h
//  RealDemo
//
//  Created by lucaswang on 2024/1/10.
//

#import <UIKit/UIKit.h>

@interface PopupView : UIView

//- (void)showInView:(UIView *)view;
//- (void)dismiss;
- (void)showPopupView;
- (void)hidePopupView;

@end
