//
//  RealDog.h
//  RealSDK
//
//  Created by lucaswang on 2024/1/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RealDog : NSObject

+ (void) eat;
@end

NS_ASSUME_NONNULL_END
